php
Copy code
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php';

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    echo "Received token: " . htmlspecialchars($token) . "<br>";

    // Verify the token and update the player's status
    $sql = "UPDATE players SET status = 'Active' WHERE token = ?";

    $sql = "UPDATE players SET status = 'Active' WHERE token = ? AND token_expiry > NOW()";
    $query = $conn->prepare($sql);
    
    if ($query === false) {
        die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
    }
    
    if (!$query->bind_param("s", $token)) {
        die("Binding parameters failed: (" . $query->errno . ") " . $query->error);
    }
    
    if (!$query->execute()) {
        die("Execute failed: (" . $query->errno . ") " . $query->error);
    }

    if ($query->affected_rows > 0) {
        echo "Your account has been activated successfully.";
    } else {
        echo "Invalid token or account already activated.";
    }

    $query->close();
} else {
    echo "Invalid access.";
}

$result = $conn->query("SELECT 1");
if ($result === false) {
    die("Query failed: (" . $conn->errno . ") " . $conn->error);
}
echo "Database connection successful.<br>";

$conn->close();
?>