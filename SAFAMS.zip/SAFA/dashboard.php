<?php
  session_start();
  if (!isset($_SESSION['username'])) {
      header("Location: login.php");
      exit();
  }

  include 'db.php';

  

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script>
      function clearForm() {
          document.getElementById('idNumber').value = '';
          document.getElementById('playerDetails').innerHTML = '';
          document.getElementById('registerButton').style.display = 'none';
      }
      document.addEventListener("DOMContentLoaded", function() {
            var dropdown = document.querySelector(".dropdown");
            dropdown.addEventListener("click", function() {
                this.classList.toggle("active");
            });

            var userDropdown = document.querySelector(".user-dropdown");
            userDropdown.addEventListener("click", function() {
                this.classList.toggle("active");
            });
        });
    </script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        @import url("https://fonts.googleapis.com/css?family=Open+Sans&display=swap");
        @import url("https://fonts.googleapis.com/css?family=Titillium+Web:300");

        body {
            font-family: 'Roboto', sans-serif;
            background-color: #04295b;
            margin: 0;
            padding: 0;
        }
        #top-bar {
            background-color: #000000;
            padding: 10px 20px;
            padding-right: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        #top-bar .logo {
            font-size: 24px;
            font-weight: bold;
            display: flex;
            align-items: center;
        }
        #top-bar .logo a {
            text-decoration: none;
            font-size: 1.8em;
            font-weight: bold;
            color: #f0f5f7;
        }
        #top-bar .logo a .logo-my {
            color: #d13747;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif, sans-serif;
            font-style: italic;
        }
        #top-bar .logo a .logo-safa {
            color: #f0f5f7;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif, sans-serif;
            font-style: italic;
        }
        #top-bar div {
            color: white;
        }
        .sidebar {
            width: 250px;
            background-color: #003366;
            position: fixed;
            height: 100%;
            padding-top: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            width: 100%;
        }
        .sidebar ul li a {
            display: block;
            color: white;
            padding: 10px;
            text-decoration: none;
        }
        .sidebar ul li a .nav-icon {
            display: table-cell;
            width: 60px;
            height: 36px;
            text-align: center;
            vertical-align: middle;
            font-size: 18px;
        }
        .sidebar ul li a .nav-text {
            display: table-cell;
            vertical-align: middle;
            width: 150px;
            font-family: 'Titillium Web', sans-serif;
        }
        .sidebar ul li a:hover,
        .sidebar ul li a.current {
            background-color: #04295b;
            color: #d13747;
        }
        .sidebar ul.logout {
            position: absolute;
            bottom: 11%;
            background-color: red;
            color: #fff;
            text-align: center;
            width: 100%;
        }
        .dropdown {
            position: relative;
        }
        .dropdown-content {
            display: none;
            flex-direction: column;
            background-color: #003366;
            padding: 0;
            width: 100%;
        }
        .dropdown-content a {
            padding: 10px;
            color: white;
            text-decoration: none;
        }
        .dropdown-content a:hover {
            background-color: #04295b;
        }
        .dropdown.active .dropdown-content {
            display: flex;
        }
        .user-dropdown {
            position: relative;
            display: inline-block;
        }
        .user-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: #000000;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .user-dropdown-content a {
            color: white;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .user-dropdown-content a:hover {
            background-color: #ddd;
            color: black;
        }
        .user-dropdown.active .user-dropdown-content {
            display: block;
        }
        .container {
            padding-top: 20px;
            margin-left: 270px;
            margin-right: 10px;
            padding: 10px;
            border-radius: 15px; /* Add rounded corners */
            background-color: #f0f5f7; /* Optional: add background color */
        }
        h1 {
            font-size: 30px;
            font-weight: bold;
            color: #04295b;
            text-align: center;
        }
        h3 {
            font-size: 15px;
            font-style: italic;
            color: #d13747;
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 20px;
        }
        input[type="text"] {
            text-align: center;
            padding: 20px 0;
            border: 2px solid #ccc;
            border-radius: 10px;
            width: 100%;
        }
        #playerDetails {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            background: #f0f5f7;
            padding: 20px;
            border-radius: 5px;
            width: 100%;
            max-width: 50%;
            margin: 0 auto;
        }
        .player-info {
            flex-basis: 40%;
            margin-bottom: 10px;
        }
        .player-info p {
            margin: 5px 0;
            font-size: 20px;
            line-height: 1.6;
            font-style: italic;
            color: #04295b;
        }
        .player-photo {
            flex-basis: 40%;
            display: flex;
            justify-content: flex-end;
        }
        .player-photo-img {
            width: 180px;
            height: auto;
        }
        .btn {
            padding: 10px 20px;
            background-color: #d13747;
            color: #fff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            font-weight: 700;
            text-align: center;
            margin: 5px;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #04295b;
        }
        .error {
            color: red;
            font-weight: bold;
            text-align: center;
        }

        /* Styles for the dashboard cards */
        .dashboard-card {
            display: flex;
            flex-direction: column;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            background-color: #fff;
        }
        .card-header {
            background-color: #04295b;
            color: white;
            padding: 10px 20px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }
        .card-body {
            display: flex;
            flex-direction: column;
            padding: 20px;
        }
        .dashboard-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f0f5f7;
        }
        .dashboard-item h3 {
            margin: 0;
            color: #d13747;
        }
        .dashboard-item p {
            font-size: 24px;
            color: #04295b;
            margin: 0;
        }
    </style>

    
    <title>Register Player</title>
</head>
  <body>
  <div id="top-bar">
        <div class="logo">
            <a href="#"><span class="logo-my">My</span><span class="logo-safa">SAFA</span></a>
        </div>
        <div class="user-dropdown">
            <?php echo htmlspecialchars($_SESSION['username']); ?> <i class="fa fa-caret-down"></i>
            <div class="user-dropdown-content">
                <a href="#">Profile</a>
                <a href="#">Settings</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div>
  <div class="sidebar">
        <div class="menu">
            <ul>
                <li><a href="dashboard.php" class="current"><i class="fa fa-dashboard fa-2x nav-icon"></i><span class="nav-text">Dashboard</span></a></li>
                <li class="dropdown">
                    <a href="#"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Manage</span><i class="fa fa-angle-down fa-2x nav-icon"></i></a>
                    <div class="dropdown-content">
                        <a href="manage_leagues.php">Manage League</a>
                        <a href="manage_teams.php">Manage Team</a>
                        <a href="manage_players.php">Manage Players</a>
                    </div>
                </li>
                <li><a href="register.php"><i class="fa fa-home fa-2x nav-icon"></i><span class="nav-text">Register Player</span></a></li>
                <li><a href="register_team.php"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Register Club</span></a></li>
                <li><a href="register_league.php"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Register League</span></a></li>
            </ul>
            <ul class="logout">
                <li>
                    <a href="logout.php">
                        <i class="fa fa-power-off fa-2x nav-icon"></i>
                        <span class="nav-text">Logout</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <br>
    <div class="container">
      <header>
          <h1>Register a Player</h1>
      </header>
      <main>
            <div class="dashboard-card">
                <div class="card-header">
                    <h2>Dashboard Overview</h2>
                </div>

                <div class="card-body">
                    <div class="dashboard-item">
                        <h3>Registered Players</h3>
                        <p id="registeredPlayersCount">0</p>
                    </div>

                    <div class="dashboard-item">
                        <h3>Number of Leagues</h3>
                        <p id="leaguesCount">0</p>
                    </div>

                    <div class="dashboard-item">
                        <h3>Leagues Open</h3>
                        <p id="leaguesOpenCount">0</p>
                    </div>

                    <div class="dashboard-item">
                        <h3>Leagues Closed</h3>
                        <p id="leaguesClosedCount">0</p>
                    </div>

                    <div class="dashboard-item">
                        <h3>Number of Teams</h3>
                        <p id="teamsCount">0</p>
                    </div>
            </div>
        </div>
      </main>
      
  </div>
    
    <script>
      const nav = document.querySelector(".nav");

      const fixNav = () => {
        if (window.scrollY > nav.offsetHeight + 150) nav.classList.add("active");
        else nav.classList.remove("active");
      };

      window.addEventListener("scroll", fixNav);

      document.addEventListener("DOMContentLoaded", function() {
        // Function to fetch and update dashboard counts
        function updateDashboardCounts() {
            // Assume you have APIs or functions to fetch these counts from your backend
            // For demonstration purposes, let's assume they return hardcoded values
            const registeredPlayersCount = 150;
            const leaguesCount = 10;
            const leaguesOpenCount = 5;
            const leaguesClosedCount = 5;
            const teamsCount = 20;

            // Update the HTML content with the fetched counts
            document.getElementById('registeredPlayersCount').textContent = registeredPlayersCount;
            document.getElementById('leaguesCount').textContent = leaguesCount;
            document.getElementById('leaguesOpenCount').textContent = leaguesOpenCount;
            document.getElementById('leaguesClosedCount').textContent = leaguesClosedCount;
            document.getElementById('teamsCount').textContent = teamsCount;
        }

        // Call the function to update counts when the page loads
        updateDashboardCounts();
    });
    </script>
  </body>
</html>
