<?php
session_start();
if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'error' => 'Not logged in']);
    exit();
}

include 'db.php';

$id = $_POST['id'];
$teamId = $_POST['teamId'];
$contactNumber = $_POST['contactNumber'];
$email = $_POST['email'];

if (empty($id) || empty($teamId) || empty($contactNumber) || empty($email)) {
    echo json_encode(['success' => false, 'error' => 'All fields are required']);
    exit();
}

$query = $conn->prepare("UPDATE players SET team_id = ?, contact_number = ?, email = ? WHERE id = ?");
if ($query === false) {
    echo json_encode(['success' => false, 'error' => 'Error preparing query: ' . $conn->error]);
    exit();
}

$query->bind_param("issi", $teamId, $contactNumber, $email, $id);
$executeResult = $query->execute();
if ($executeResult === false) {
    echo json_encode(['success' => false, 'error' => 'Error executing query: ' . $query->error]);
    exit();
}

$query->close();
$conn->close();

echo json_encode(['success' => true]);
?>
