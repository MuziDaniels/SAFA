<?php
  session_start();
  if (!isset($_SESSION['username'])) {
      header("Location: login.php");
      exit();
  }

  include 'db.php';

  $details = null;
  $error = null;

  function isValidSouthAfricanID($id) {
      return preg_match('/^\d{13}$/', $id);
  }

  if (isset($_GET['idNumber'])) {
      $idNumber = $_GET['idNumber'];

      if (isValidSouthAfricanID($idNumber)) {
          $query = $conn_homeaffairs->prepare("SELECT full_name, surname, dob, place_of_birth, gender, photograph FROM homeaffairs WHERE id_number = ?");
          
          if ($query) {
              $query->bind_param("s", $idNumber);
              $query->execute();
              $result = $query->get_result();
              if ($result->num_rows > 0) {
                  $details = $result->fetch_assoc();
              } else {
                  $error = "ID not found";
              }
              $query->close();
          } else {
              $error = "Error preparing statement: " . $conn_homeaffairs->error;
          }
      } else {
          $error = "Invalid South African ID number format";
      }
  }

  if (isset($_POST['register'])) {
      $idNumber = $_POST['idNumber'];
      $fullName = $_POST['fullName'];
      $surname = $_POST['surname'];
      $dob = $_POST['dob'];
      $placeOfBirth = $_POST['placeOfBirth'];
      $gender = $_POST['gender'];
      $photograph = $_POST['photograph'];
      
      $checkQuery = $conn->prepare("SELECT * FROM players WHERE id_number = ?");
      $checkQuery->bind_param("s", $idNumber);
      $checkQuery->execute();
      $result = $checkQuery->get_result();
      
      if ($result->num_rows == 0) {
          $insertQuery = $conn->prepare("INSERT INTO players (id_number, full_name, surname, dob, place_of_birth, gender, photograph) VALUES (?, ?, ?, ?, ?, ?, ?)");
          $insertQuery->bind_param("sssssss", $idNumber, $fullName, $surname, $dob, $placeOfBirth, $gender, $photograph);
          $insertQuery->execute();
          $insertQuery->close();
          header("Location: complete_registration.php?idNumber=" . $idNumber);
          exit();
      } else {
          $error = "Player with this ID number is already registered.";
      }
      $checkQuery->close();
  }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script>
      function clearForm() {
          document.getElementById('idNumber').value = '';
          document.getElementById('playerDetails').innerHTML = '';
          document.getElementById('registerButton').style.display = 'none';
      }
      document.addEventListener("DOMContentLoaded", function() {
            var dropdown = document.querySelector(".dropdown");
            dropdown.addEventListener("click", function() {
                this.classList.toggle("active");
            });

            var userDropdown = document.querySelector(".user-dropdown");
            userDropdown.addEventListener("click", function() {
                this.classList.toggle("active");
            });
        });
    </script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        @import url("https://fonts.googleapis.com/css?family=Open+Sans&display=swap");
        @import url("https://fonts.googleapis.com/css?family=Titillium+Web:300");

        body {
            font-family: 'Roboto', sans-serif;
            background-color: #04295b;
            margin: 0;
            padding: 0;
        }
        #top-bar {
            background-color: #000000;
            padding: 10px 20px;
            padding-right: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        #top-bar .logo {
            font-size: 24px;
            font-weight: bold;
            display: flex;
            align-items: center;
        }
        #top-bar .logo a {
            text-decoration: none;
            font-size: 1.8em;
            font-weight: bold;
            color: #f0f5f7;
        }
        #top-bar .logo a .logo-my {
            color: #d13747;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif, sans-serif;
            font-style: italic;
        }
        #top-bar .logo a .logo-safa {
            color: #f0f5f7;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif, sans-serif;
            font-style: italic;
        }
        #top-bar div {
            color: white;
        }
        .sidebar {
            width: 250px;
            background-color: #003366;
            position: fixed;
            height: 100%;
            padding-top: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            width: 100%;
        }
        .sidebar ul li a {
            display: block;
            color: white;
            padding: 10px;
            text-decoration: none;
        }
        .sidebar ul li a .nav-icon {
            display: table-cell;
            width: 60px;
            height: 36px;
            text-align: center;
            vertical-align: middle;
            font-size: 18px;
        }
        .sidebar ul li a .nav-text {
            display: table-cell;
            vertical-align: middle;
            width: 150px;
            font-family: 'Titillium Web', sans-serif;
        }
        .sidebar ul li a:hover,
        .sidebar ul li a.current {
            background-color: #04295b;
            color: #d13747;
        }
        .sidebar ul.logout {
            position: absolute;
            bottom: 11%;
            background-color: red;
            color: #fff;
            text-align: center;
            width: 100%;
        }
        .dropdown {
            position: relative;
        }
        .dropdown-content {
            display: none;
            flex-direction: column;
            background-color: #003366;
            padding: 0;
            width: 100%;
        }
        .dropdown-content a {
            padding: 10px;
            color: white;
            text-decoration: none;
        }
        .dropdown-content a:hover {
            background-color: #04295b;
        }
        .dropdown.active .dropdown-content {
            display: flex;
        }
        .user-dropdown {
            position: relative;
            display: inline-block;
        }
        .user-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: #000000;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .user-dropdown-content a {
            color: white;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .user-dropdown-content a:hover {
            background-color: #ddd;
            color: black;
        }
        .user-dropdown.active .user-dropdown-content {
            display: block;
        }
        .container {
            padding-top: 20px;
            margin-left: 270px;
            margin-right: 10px;
            padding: 10px;
            border-radius: 15px; /* Add rounded corners */
            background-color: #f0f5f7; /* Optional: add background color */
        }
        h1 {
            font-size: 30px;
            font-weight: bold;
            color: #04295b;
            text-align: center;
        }
        h3 {
            font-size: 15px;
            font-style: italic;
            color: #d13747;
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 20px;
        }
        input[type="text"] {
            text-align: center;
            padding: 20px 0;
            border: 2px solid #ccc;
            border-radius: 10px;
            width: 100%;
        }
        #playerDetails {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            background: #f0f5f7;
            padding: 20px;
            border-radius: 5px;
            width: 100%;
            max-width: 50%;
            margin: 0 auto;
        }
        .player-info {
            flex-basis: 40%;
            margin-bottom: 10px;
        }
        .player-info p {
            margin: 5px 0;
            font-size: 20px;
            line-height: 1.6;
            font-style: italic;
            color: #04295b;
        }
        .player-photo {
            flex-basis: 40%;
            display: flex;
            justify-content: flex-end;
        }
        .player-photo-img {
            width: 180px;
            height: auto;
        }
        .btn {
            padding: 10px 20px;
            background-color: #d13747;
            color: #fff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            font-weight: 700;
            text-align: center;
            margin: 5px;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #04295b;
        }
        .error {
            color: red;
            font-weight: bold;
            text-align: center;
        }
    </style>
    
    <title>Register Player</title>
</head>
  <body>
  <div id="top-bar">
        <div class="logo">
            <a href="#"><span class="logo-my">My</span><span class="logo-safa">SAFA</span></a>
        </div>
        <div class="user-dropdown">
            <?php echo htmlspecialchars($_SESSION['username']); ?> <i class="fa fa-caret-down"></i>
            <div class="user-dropdown-content">
                <a href="#">Profile</a>
                <a href="#">Settings</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div>
  <div class="sidebar">
        <div class="menu">
            <ul>
                <li><a href="dashboard.php"><i class="fa fa-dashboard fa-2x nav-icon"></i><span class="nav-text">Dashboard</span></a></li>
                <li class="dropdown">
                    <a href="#"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Manage</span><i class="fa fa-angle-down fa-2x nav-icon"></i></a>
                    <div class="dropdown-content">
                        <a href="manage_leagues.php">Manage League</a>
                        <a href="manage_teams.php">Manage Team</a>
                        <a href="manage_players.php">Manage Players</a>
                    </div>
                </li>
                <li><a href="register.php" class="current"><i class="fa fa-home fa-2x nav-icon"></i><span class="nav-text">Register Player</span></a></li>
                <li><a href="register_team.php"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Register Club</span></a></li>
                <li><a href="register_league.php"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Register League</span></a></li>
            </ul>
            <ul class="logout">
                <li>
                    <a href="logout.php">
                        <i class="fa fa-power-off fa-2x nav-icon"></i>
                        <span class="nav-text">Logout</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <br>
    <div class="container">
      <header>
          <h1>Register a Player</h1>
      </header>
      <main>
          <form method="GET" action="register.php">
              <h3 for="idNumber">Enter ID Number:</h3>
              <input type="text" id="idNumber" name="idNumber" required pattern="\d{13}" title="Enter a valid 13-digit South African ID number">
              <button type="submit" class="btn">Fetch Details</button>
              <button type="button" class="btn" onclick="clearForm()">Clear</button>
          </form>

          <?php if ($details): ?>
          <div id="playerDetails" class="player-details">
            <div class="player-info">
                <p>Full Name: <?php echo htmlspecialchars($details['full_name']); ?></p>
                <p>Surname: <?php echo htmlspecialchars($details['surname']); ?></p>
                <p>Date of Birth: <?php echo htmlspecialchars($details['dob']); ?></p>
                <p>Place of Birth: <?php echo htmlspecialchars($details['place_of_birth']); ?></p>
                <p>Gender: <?php echo htmlspecialchars($details['gender']); ?></p>
            </div>
            <div class="player-photo">
                <img src="data:image/jpeg;base64,<?php echo base64_encode($details['photograph']); ?>" alt="Player Photograph" class="player-photo-img"/>
            </div>
          </div>
          
          <form method="POST" action="register.php">
              <input type="hidden" name="idNumber" value="<?php echo htmlspecialchars($idNumber); ?>">
              <input type="hidden" name="fullName" value="<?php echo htmlspecialchars($details['full_name']); ?>">
              <input type="hidden" name="surname" value="<?php echo htmlspecialchars($details['surname']); ?>">
              <input type="hidden" name="dob" value="<?php echo htmlspecialchars($details['dob']); ?>">
              <input type="hidden" name="placeOfBirth" value="<?php echo htmlspecialchars($details['place_of_birth']); ?>">
              <input type="hidden" name="gender" value="<?php echo htmlspecialchars($details['gender']); ?>">
              <input type="hidden" name="photograph" value="<?php echo base64_encode($details['photograph']); ?>">
              <button type="submit" name="register" class="btn" id="registerButton">Register Player</button>
          </form>
          <?php elseif ($error): ?>
          <p class="error"><?php echo htmlspecialchars($error); ?></p>
          <?php endif; ?>
      </main>
      
  </div>
    
    <script>
      const nav = document.querySelector(".nav");

      const fixNav = () => {
        if (window.scrollY > nav.offsetHeight + 150) nav.classList.add("active");
        else nav.classList.remove("active");
      };

      window.addEventListener("scroll", fixNav);
    </script>
  </body>
</html>
