<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to MySAFA</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>

<body>
    <header>
        <nav>
            <div class="logo">
                <a href="#"><span class="logo-my">My</span><span class="logo-safa">SAFA</span></a>
            </div>
            <ul>
                <li><a href="#features">Features</a></li>
                <li><a href="#about">Contact Us</a></li>
                <li><a href="login.php" class="btn">Login</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section id="hero">
            <div class="hero-content">
                <h1>Welcome to MySAFA</h1>
                <p>A secure platform for managing your sports teams and players.</p>
                <a href="login.php" class="btn">Login</a>
                <br>
                <br>
                <br>
            </div>
        </section>

        <section id="features">
            <h2>Key Features</h2>
            <div class="features-container">
                <div class="feature">
                    <img src="images/icon1.jpg" alt="Football Icon">
                    <h3>Team Management</h3>
                    <p>Efficiently manage your sports teams with our intuitive interface.</p>
                </div>
                <div class="feature">
                    <img src="images/icon2.jpg" alt="Player Icon">
                    <h3>Player Registration</h3>
                    <p>Register players securely and verify their details with our advanced tools.</p>
                </div>
                <div class="feature">
                    <img src="images/icon3.jpg" alt="League Icon">
                    <h3>League Participation</h3>
                    <p>Join open leagues and showcase your team's skills on a competitive platform.</p>
                </div>
            </div>
        </section>
    </main>
    <footer>
 
        <div class="footer-content" id="about">
            <p>&copy; 2024 MySAFA. All rights reserved.</p>
            <form action="#" method="POST">
                <input type="email" name="email" placeholder="e-mail">
                <button type="submit">Subscribe</button>
            </form>
        </div>

    </footer>
</body>

</html>
