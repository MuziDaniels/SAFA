
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAFA Player Registration</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #2c3e50;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 100%;
            max-width: 960px;
            margin: 0 auto;
            padding: 50px;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        header {
            text-align: center;
            padding: 20px 0;
            background-color: #2c3e50;
            color: #fff;
            border-radius: 8px 8px 0 0;
        }

        h1 {
            margin: 0;
            font-size: 36px;
            font-weight: bold;
            color: #e67e22;
        }

        p {
            color: #ecf0f1;
            font-size: 18px;
            margin-bottom: 10px;
        }

        .btn {
            display: inline-block;
            padding: 12px 24px;
            color: #fff;
            background: linear-gradient(to right, #e67e22, #d35400);
            border: none;
            border-radius: 25px;
            text-decoration: none;
            cursor: pointer;
            text-align: center;
            margin: 5px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background: linear-gradient(to right, #d35400, #e67e22);
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>SAFA Player Registration</h1>
            <p>Register and Manage players and their teams effortlessly</p>
            <p>Our system is connected to the Home Affairs database system for streamlined player details</p>
        </header>
        <main>
            <a href="login.php" class="btn">Login</a>
        </main>
    </div>
</body>
</html>