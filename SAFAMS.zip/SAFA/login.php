<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('db.php');
session_start();

// Check if the user is already logged in
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    // Redirect to the dashboard if already logged in
    header("Location: register.php");
    exit;
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = strtolower($_POST['email']); // Convert email to lowercase
    $password = $_POST['password'];
    
    // Prepare and bind
    if ($stmt = $conn->prepare("SELECT id, username, password FROM users WHERE LOWER(email) = ?")) {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // Bind result variables
            $stmt->bind_result($id, $username, $hashed_password);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                // Password is correct
                $_SESSION['userid'] = $id;
                $_SESSION['username'] = $username;
                $_SESSION['logged_in'] = true; // Set the logged_in session variable
                header("Location: register.php");
                exit; // Always include exit after header redirection
            } else {
                // Password is incorrect
                $error = "Invalid password.";
            }
        } else {
            // Email doesn't exist
            $error = "Email doesn't exist.";
        }

        $stmt->close();
    } else {
        echo "Prepare statement failed: (" . $conn->errno . ") " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <style media="screen">
        *,
        *:before,
        *:after {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #041953; /* White background */
            font-family: 'Poppins', sans-serif;
        }

        .background {
            width: 430px;
            height: 520px;
            position: absolute;
            transform: translate(-50%, -50%);
            left: 50%;
            top: 50%;
        }

        .background .shape {
            height: 200px;
            width: 200px;
            position: absolute;
            border-radius: 50%;
        }

        .shape:first-child {
            background: linear-gradient(#214db4, #214db4); /* Navy blue gradient */
            left: -80px;
            top: -80px;
        }

        .shape:last-child {
            background: linear-gradient(to right, #ff0000, #ff0000); /* Red gradient */
            right: -30px;
            bottom: -80px;
        }

        form {
            height: 520px;
            width: 400px;
            background-color: rgba(255, 255, 255, 0.85); /* White with transparency */
            position: absolute;
            transform: translate(-50%, -50%);
            top: 50%;
            left: 50%;
            border-radius: 10px;
            box-shadow: 0 0 40px rgba(0, 0, 0, 0.1);
            padding: 50px 35px;
        }

        form * {
            color: #080710; /* Dark text color */
        }

        form h3 {
            font-size: 32px;
            font-weight: 500;
            line-height: 42px;
            text-align: center;
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-top: 20px;
            font-size: 16px;
            font-weight: 500;
        }

        input {
            display: block;
            height: 50px;
            width: 100%;
            background-color: rgba(255, 255, 255, 0.95); /* White with higher opacity */
            border-radius: 3px;
            padding: 0 10px;
            margin-top: 8px;
            font-size: 14px;
            font-weight: 300;
        }

        .password-wrapper {
            position: relative;
        }

        .toggle-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
        }

        button {
            margin-top: 30px;
            width: 100%;
            background-color: #ff0000; /* Red button */
            color: #ffffff; /* White text */
            padding: 15px 0;
            font-size: 18px;
            font-weight: 600;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #cc0000; /* Darker red on hover */
        }

        .back-button {
            display: inline-block;
            margin-top: 20px;
            text-align: center;
            width: 100%;
            background-color: #001f3f; /* Navy blue background */
            color: #ffffff; /* White text */
            padding: 10px 0;
            font-size: 18px;
            font-weight: 600;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }

        .back-button:hover {
            background-color: #002f5f; /* Darker navy blue on hover */
        }

        .error {
            color: red;
            font-size: 14px;
            margin-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="background">
        <div class="shape"></div>
        <div class="shape"></div>
    </div>
    <form action="login.php" method="post">
        <h3>Login Here</h3>

        <?php
        if (!empty($error)) {
            echo '<p class="error">' . $error . '</p>';
        }
        ?>

        <label for="email">Email</label>
        <input type="text" placeholder="Email" id="email" name="email" required>

        <label for="password">Password</label>
        <div class="password-wrapper">
            <input type="password" placeholder="Password" id="password" name="password" required>
            <i class="far fa-eye toggle-password" id="togglePassword"></i>
        </div>

        <button type="submit">Log In</button>
        <p>Click here to <a href="signup.php">sign up</a></p>
     
        <a href="home.php">Home</a>
    </form>
    <script>
        document.getElementById('togglePassword').addEventListener('click', function (e) {
            const passwordInput = document.getElementById('password');
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('fa-eye-slash');
        });
    </script>
</body>
</html>
