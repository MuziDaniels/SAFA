<?php
    session_start();
    if (!isset($_SESSION['username'])) {
        header("Location: login.php");
        exit();
    }
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require 'phpmailer/src/Exception.php';
    require 'phpmailer/src/PHPMailer.php';
    require 'phpmailer/src/SMTP.php';

    include 'db.php';

    $idNumber = $_GET['idNumber'] ?? null;
    $error = null;
    $teams = [];
    $leagues = [];

    if (!$idNumber) {
        $error = "Invalid access.";
    } else {
        // Fetch player details to pre-fill the form
        $query = $conn->prepare("SELECT * FROM players WHERE id_number = ?");
        $query->bind_param("s", $idNumber);
        $query->execute();
        $result = $query->get_result();
        if ($result->num_rows == 1) {
            $player = $result->fetch_assoc();
        } else {
            $error = "Player not found.";
        }
        $query->close();

        // Fetch available leagues
        $leagueQuery = $conn->query("SELECT * FROM leagues");
        while ($row = $leagueQuery->fetch_assoc()) {
            $leagues[] = $row;
        }

        // Fetch available teams
        $teamQuery = $conn->query("SELECT * FROM teams");
        while ($row = $teamQuery->fetch_assoc()) {
            $teams[] = $row;
        }
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $teamId = $_POST['teamId'];
        $leagueId = $_POST['leagueId'];
        $contactNumber = $_POST['contactNumber'];
        $email = $_POST['email'];

        // Handle document upload
        if (isset($_FILES['document']) && $_FILES['document']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/'; // Specify the directory where you want to store the uploaded files
            $fileName = basename($_FILES['document']['name']);
            $fileType = $_FILES['document']['type'];
            $targetPath = $uploadDir . $fileName;

            if (move_uploaded_file($_FILES['document']['tmp_name'], $targetPath)) {
                // File uploaded successfully, insert document information into the database
                $insertDocumentQuery = $conn->prepare("INSERT INTO documents (id_number, document_name, document_type) VALUES (?, ?, ?)");
                $insertDocumentQuery->bind_param("sss", $idNumber, $fileName, $fileType);
                $insertDocumentQuery->execute();
                $insertDocumentQuery->close();
                
            } else {
                $error = "Failed to upload the document.";
            }
        } else {
            switch ($_FILES['document']['error']) {
                case UPLOAD_ERR_INI_SIZE:
                    $error = "The uploaded file exceeds the upload_max_filesize directive in php.ini.";
                    break;
                case UPLOAD_ERR_FORM_SIZE:
                    $error = "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.";
                    break;
                case UPLOAD_ERR_PARTIAL:
                    $error = "The uploaded file was only partially uploaded.";
                    break;
                case UPLOAD_ERR_NO_FILE:
                    $error = "No file was uploaded.";
                    break;
                case UPLOAD_ERR_NO_TMP_DIR:
                    $error = "Missing a temporary folder.";
                    break;
                case UPLOAD_ERR_CANT_WRITE:
                    $error = "Failed to write file to disk.";
                    break;
                case UPLOAD_ERR_EXTENSION:
                    $error = "File upload stopped by extension.";
                    break;
                default:
                    $error = "Unknown upload error.";
                    break;
            }
        }

        $updateQuery = $conn->prepare("UPDATE players SET league_id = ?, team_id = ?, contact_number = ?, email = ?, status = 'Pending' WHERE id_number = ?");
        $updateQuery->bind_param("issss", $leagueId, $teamId, $contactNumber, $email, $idNumber);
        if ($updateQuery->execute()) {
            // Generate a unique token or link
            $token = bin2hex(random_bytes(16));
            $expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));
        
            // Store the token in the database
            $tokenQuery = $conn->prepare("UPDATE players SET token = ?, token_expiry = ? WHERE id_number = ?");
            $tokenQuery->bind_param("sss", $token, $expiry, $idNumber);
            $tokenQuery->execute();
            $tokenQuery->close();
            $activationLink = " https://393a-196-253-221-233.ngrok-free.app/SAFA/activate_player.php?token=" . $token;
            $mail = new PHPMailer(true);

            try {
                //Server settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'lazer7545@gmail.com';
                $mail->Password = 'jndwkobxmfnrvmoe';
                $mail->SMTPSecure = 'ssl';
                $mail->Port = 465;

                //Recipients
                $mail->setFrom('lazer7545@gmail.com', 'MySAFA');
                $mail->addAddress($email, $player['full_name']);

                //Content
                $mail->isHTML(true);
                $mail->Subject = 'Player Registration Confirmation';
                $mail->Body = 'Dear ' . $player['full_name'] . ',<br><br>Your registration with MySAFA has been completed successfully. Please click the following link to activate your account:<br><br><a href="' . $activationLink . '">Activate Account</a><br><br>If you do not activate your account within 24 hours, your status will remain pending.<br><br>Thank you for registering!<br><br>Best regards,<br>MySAFA Team';
                $mail->send();
                echo '<script>alert("Player details updated successfully."); window.location.href = "manage_players.php";</script>';
                exit(); // Exit to prevent further execution
            } catch (Exception $e) {
                $error = "Message could not be sent. Mailer Error: " . $mail->ErrorInfo;
            }
        } else {
            $error = "Failed to update player details.";
        }

        $updateQuery->close();
    }

    $idNumber = $_GET['idNumber'] ?? null;
    if ($idNumber) {
        $query = $conn_homeaffairs->prepare("SELECT full_name, surname, dob, place_of_birth, gender, photograph FROM homeaffairs WHERE id_number = ?");
        $query->bind_param("s", $idNumber);
        $query->execute();
        $result = $query->get_result();
        if ($result->num_rows > 0) {
            $homeaffairsDetails = $result->fetch_assoc();
        } else {
            $error = "ID not found";
        }
        $query->close();
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Registration</title>
   
    <script>
      function clearForm() {
          document.getElementById('idNumber').value = '';
          document.getElementById('playerDetails').innerHTML = '';
          document.getElementById('registerButton').style.display = 'none';
      }
      document.addEventListener("DOMContentLoaded", function() {
            var dropdown = document.querySelector(".dropdown");
            dropdown.addEventListener("click", function() {
                this.classList.toggle("active");
            });

            var userDropdown = document.querySelector(".user-dropdown");
            userDropdown.addEventListener("click", function() {
                this.classList.toggle("active");
            });
        });
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
     
    <style>
            @import url("https://fonts.googleapis.com/css?family=Open+Sans&display=swap");
            @import url("https://fonts.googleapis.com/css?family=Titillium+Web:300");

            body {
                font-family: 'Roboto', sans-serif;
                background-color: #04295b;
                margin: 0;
                padding: 0;
            }
            #top-bar {
                background-color: #000000;
                padding: 10px 20px;
                padding-right: 30px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            #top-bar .logo {
                font-size: 24px;
                font-weight: bold;
                display: flex;
                align-items: center;
            }
            #top-bar .logo a {
                text-decoration: none;
                font-size: 1.8em;
                font-weight: bold;
                color: #f0f5f7;
            }
            #top-bar .logo a .logo-my {
                color: #d13747;
                font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif, sans-serif;
                font-style: italic;
            }
            #top-bar .logo a .logo-safa {
                color: #f0f5f7;
                font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif, sans-serif;
                font-style: italic;
            }
            #top-bar div {
                color: white;
            }
            .sidebar {
                width: 250px;
                background-color: #003366;
                position: fixed;
                height: 100%;
                padding-top: 20px;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
            }
            .sidebar ul {
                list-style-type: none;
                padding: 0;
                margin: 0;
            }
            .sidebar ul li {
                width: 100%;
            }
            .sidebar ul li a {
                display: block;
                color: white;
                padding: 10px;
                text-decoration: none;
            }
            .sidebar ul li a .nav-icon {
                display: table-cell;
                width: 60px;
                height: 36px;
                text-align: center;
                vertical-align: middle;
                font-size: 18px;
            }
            .sidebar ul li a .nav-text {
                display: table-cell;
                vertical-align: middle;
                width: 150px;
                font-family: 'Titillium Web', sans-serif;
            }
            .sidebar ul li a:hover,
            .sidebar ul li a.current {
                background-color: #04295b;
                color: #d13747;
            }
            .sidebar ul.logout {
                position: absolute;
                bottom: 11%;
                background-color: red;
                color: #fff;
                text-align: center;
                width: 100%;
            }
            .dropdown {
                position: relative;
            }
            .dropdown-content {
                display: none;
                flex-direction: column;
                background-color: #003366;
                padding: 0;
                width: 100%;
            }
            .dropdown-content a {
                padding: 10px;
                color: white;
                text-decoration: none;
            }
            .dropdown-content a:hover {
                background-color: #04295b;
            }
            .dropdown.active .dropdown-content {
                display: flex;
            }
            .user-dropdown {
                position: relative;
                display: inline-block;
            }
            .user-dropdown-content {
                display: none;
                position: absolute;
                right: 0;
                background-color: #000000;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
            }
            .user-dropdown-content a {
                color: white;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }
            .user-dropdown-content a:hover {
                background-color: red;
                color: black;
            }
            .user-dropdown.active .user-dropdown-content {
                display: block;
            }
            .container {
                padding-top: 20px;
                margin-left: 270px;
                margin-right: 10px;
                padding: 10px;
                border-radius: 15px; /* Add rounded corners */
                background-color: #f0f5f7; /* Optional: add background color */
            }
            h1 {
                font-size: 30px;
                font-weight: bold;
                color: #04295b;
                text-align: center;
            }
            h3 {
                font-size: 15px;
                font-style: italic;
                color: #d13747;
                text-align: center;
            }
            form {
                display: flex;
                flex-direction: column;
                margin-bottom: 20px;
            }
            input[type="text"] {
                text-align: center;
                padding: 14px 0;
                border: 2px solid #ccc;
                border-radius: 8px;
                width: 100%;
            }
            input[type="email"] {
                text-align: center;
                padding: 14px 0;
                border: 2px solid #ccc;
                border-radius: 8px;
                width: 100%;
            }
            #playerDetails {
                display: flex;
                flex-wrap: wrap;
                justify-content: space-between;
                background: #f0f5f7;
                border-radius: 5px;
                width: 100%;
                max-width: 50%;
                margin: 0 auto;
            }
            .player-info {
                flex-basis: 40%;
                margin-bottom: 2px;
            }
            .player-info p {
                margin: 5px 0;
                font-size: 20px;
                line-height: 1.6;
                font-style: italic;
                color: #04295b;
            }
            .player-photo {
                flex-basis: 40%;
                display: flex;
                justify-content: flex-end;
            }
            .player-photo-img {
                width: 180px;
                height: auto;
            }
            .btn {
                padding: 10px 20px;
                background-color: #d13747;
                color: #fff;
                border: none;
                border-radius: 5px;
                text-decoration: none;
                cursor: pointer;
                font-weight: 700;
                text-align: center;
                margin: 5px;
                transition: background-color 0.3s ease;
            }
            .btn:hover {
                background-color: #04295b;
            }
            .error {
                color: red;
                font-weight: bold;
                text-align: center;
            }
                  /* Style the select element */
            select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ccc;
                border-radius: 5px;
                background-color: #f0f5f7;
                font-size: 14px;
                text-align: center;
            }

            /* Style the dropdown icon */
            .select-container::after {
                content: "\25BC"; /* Unicode character for a downward arrow */
                position: absolute;
                top: 50%;
                right: 15px;
                transform: translateY(-50%);
                pointer-events: none;
                color: #000;
            }

            /* Additional styling for the select element on focus */
            select:focus {
                border-color: #d13747;
                outline: none;
                box-shadow: 0 0 5px rgba(209, 55, 71, 0.5);
            }

            /* Style for disabled select element */
            select:disabled {
                background-color: #e9ecef;
                cursor: not-allowed;
            }
    </style>
        <title>Complete Registration</title>
    </head>
  <body>

  <div id="top-bar">
        <div class="logo">
            <a href="#"><span class="logo-my">My</span><span class="logo-safa">SAFA</span></a>
        </div>
        <div class="user-dropdown">
            <?php echo htmlspecialchars($_SESSION['username']); ?> <i class="fa fa-caret-down"></i>
            <div class="user-dropdown-content">
                <a href="#">Profile</a>
                <a href="#">Settings</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div>

<!---------side----->

  <div class="sidebar">
        <div class="menu">
            <ul>
                <li><a href="dashboard.php" class="current"><i class="fa fa-dashboard fa-2x nav-icon"></i><span class="nav-text">Dashboard</span></a></li>
                <li class="dropdown">
                    <a href="#"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Manage</span><i class="fa fa-angle-down fa-2x nav-icon"></i></a>
                    <div class="dropdown-content">
                        <a href="manage_league.php">Manage League</a>
                        <a href="manage_team.php">Manage Team</a>
                        <a href="manage_player.php">Manage Players</a>
                    </div>
                </li>
                <li><a href="register.php"><i class="fa fa-home fa-2x nav-icon"></i><span class="nav-text">Register Player</span></a></li>
                <li><a href="register_team.php"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Register Club</span></a></li>
                <li><a href="register_league.php"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Register League</span></a></li>
            </ul>
            <ul class="logout">
                <li>
                    <a href="logout.php">
                        <i class="fa fa-power-off fa-2x nav-icon"></i>
                        <span class="nav-text">Logout</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <br><br><br><br><br>
    
 <!---------container----->

    <div class="container">
        <header>
            <h1>Complete Player Registration</h1>
        </header>
        <main>
           
                <?php if ($error): ?>
                    <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <?php else: ?>
                    <form method="POST" action="complete_registration.php?idNumber=<?php echo htmlspecialchars($idNumber); ?>" enctype="multipart/form-data">
                    <div id="playerDetails" class="player-details">
                        <div class="player-info">
                            <p>Full Name: <?php echo htmlspecialchars($player['full_name']); ?></p>
                            <p>Surname: <?php echo htmlspecialchars($player['surname']); ?></p>
                            <p>Date of Birth: <?php echo htmlspecialchars($player['dob']); ?></p>
                            <p>Place of Birth: <?php echo htmlspecialchars($player['place_of_birth']); ?></p>
                            <p>Gender: <?php echo htmlspecialchars($player['gender']); ?></p>
                        </div>
                        <?php if ($homeaffairsDetails): ?>
                        <div class="player-photo">
                            <img src="data:image/jpeg;base64,<?php echo base64_encode($homeaffairsDetails['photograph']); ?>" alt="Player Photograph" class="player-photo-img"/>
                        </div>
                        <?php endif; ?>
                    </div>

                    <label for="leagueId">League Name:</label>
                    <select name="leagueId" id="leagueId">
                        <option value="">Select Team</option>
                        <?php foreach ($leagues as $league) { ?>
                            <option value="<?php echo htmlspecialchars($league['league_id']); ?>" <?php echo ($player['league_id'] == $league['league_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($league['name']); ?>
                            </option>
                        <?php } ?>
                    </select>

                    
                    <label for="teamId">Team Name:</label>
                    <select class="select" id="teamId" name="teamId" required>
                        <option value="">Select Team</option>
                        <?php foreach ($teams as $team): ?>
                            <option value="<?php echo htmlspecialchars($team['team_id']); ?>" <?php echo ($player['team_id'] == $team['team_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($team['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    

                    <label for="contactNumber">Contact Number:</label>
                    <input type="text" id="contactNumber" name="contactNumber" required pattern="\d{10}" title="Enter a valid 10-digit contact number" value="<?php echo htmlspecialchars($player['contact_number']); ?>">

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required value="<?php echo htmlspecialchars($player['email']); ?>">
                    
                    <label for="document">Upload Document:</label>
                    <input type="file" name="document" accept=".pdf,.doc,.docx" required>

                    <button type="submit" class="btn">Confirm Registration</button>
                </form>
            <?php endif; ?>
        </main>
        
    </div>
</body>
</html>
