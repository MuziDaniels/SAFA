<?php
    session_start();
    if (!isset($_SESSION['username'])) {
        header("Location: login.php");
        exit();
    }

    include 'db.php';

    $error = null;
    $success = null;

    // Handle league addition
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_league'])) {
        $leagueName = $_POST['league_name'];
        $startDate = $_POST['start_date'];
        $endDate = date('Y-m-d', strtotime($startDate . ' + 6 months'));

        if (empty($leagueName)) {
            $error = "League name is required.";
        } elseif (empty($startDate)) {
            $error = "Start date is required.";
        } else {
            $insertQuery = $conn->prepare("INSERT INTO leagues (name, start_date, end_date, status) VALUES (?, ?, ?, ?)");
            $status = (new DateTime() > new DateTime($endDate)) ? 'concluded' : 'ongoing';
            $insertQuery->bind_param("ssss", $leagueName, $startDate, $endDate, $status);
            if ($insertQuery->execute()) {
                $success = "League added successfully.";
            } else {
                if ($conn->errno == 1062) { // Duplicate entry error code
                    $error = "League already exists.";
                } else {
                    $error = "Failed to add league.";
                }
            }
            $insertQuery->close();
        }
    }

    // Handle league deletion
    if (isset($_GET['delete_id'])) {
        $deleteId = $_GET['delete_id'];
        $deleteQuery = $conn->prepare("DELETE FROM leagues WHERE league_id = ?");
        $deleteQuery->bind_param("i", $deleteId);
        if ($deleteQuery->execute()) {
            $success = "League deleted successfully.";
        } else {
            $error = "Failed to delete league.";
        }
        $deleteQuery->close();
    }

    // Fetch all leagues
    $leagueQuery = $conn->query("SELECT * FROM leagues");
    $leagues = [];
    $currentDate = new DateTime();

    while ($row = $leagueQuery->fetch_assoc()) {
        $startDate = new DateTime($row['start_date']);
        $endDate = new DateTime($row['end_date']);

        if ($currentDate < $startDate) {
            $row['status'] = 'upcoming';
            $row['status_class'] = 'upcoming';
        } elseif ($currentDate > $endDate) {
            $row['status'] = 'concluded';
            $row['status_class'] = 'concluded';
        } else {
            $row['status'] = 'ongoing';
            $row['status_class'] = 'ongoing';
        }

        $leagues[] = $row;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        @import url("https://fonts.googleapis.com/css?family=Open+Sans&display=swap");

        body {
            font-family: 'Roboto', sans-serif;
            background-color: #04295b;
            margin: 0;
            padding: 0;
        }
        #top-bar {
            background-color: #000000;
            padding: 10px 20px;
            padding-right: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        #top-bar .logo {
            font-size: 24px;
            font-weight: bold;
            display: flex;
            align-items: center;
        }
        #top-bar .logo a {
            text-decoration: none;
            font-size: 1.8em;
            font-weight: bold;
            color: #f0f5f7;
        }
        #top-bar .logo a .logo-my {
            color: #d13747;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif, sans-serif;
            font-style: italic;
        }
        #top-bar .logo a .logo-safa {
            color: #f0f5f7;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif, sans-serif;
            font-style: italic;
        }
        #top-bar div {
            color: white;
        }
        .sidebar {
            width: 250px;
            background-color: #003366;
            position: fixed;
            height: 100%;
            padding-top: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            width: 100%;
        }
        .sidebar ul li a {
            display: block;
            color: white;
            padding: 10px;
            text-decoration: none;
        }
        .sidebar ul li a .nav-icon {
            display: table-cell;
            width: 60px;
            height: 36px;
            text-align: center;
            vertical-align: middle;
            font-size: 18px;
        }
        .sidebar ul li a .nav-text {
            display: table-cell;
            vertical-align: middle;
            width: 150px;
            font-family: 'Titillium Web', sans-serif;
        }
        .sidebar ul li a:hover,
        .sidebar ul li a.current {
            background-color: #04295b;
            color: #d13747;
        }
        .sidebar ul.logout {
            position: absolute;
            bottom: 11%;
            background-color: red;
            color: #fff;
            text-align: center;
            width: 100%;
        }
        .dropdown {
            position: relative;
        }
        .dropdown-content {
            display: none;
            flex-direction: column;
            background-color: #003366;
            padding: 0;
            width: 100%;
        }
        .dropdown-content a {
            padding: 10px;
            color: white;
            text-decoration: none;
        }
        .dropdown-content a:hover {
            background-color: #04295b;
        }
        .dropdown.active .dropdown-content {
            display: flex;
        }
        .user-dropdown {
            position: relative;
            cursor: pointer;
        }
        .user-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .user-dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .user-dropdown-content a:hover {
            background-color: #ddd;
            color: black;
        }
        .user-dropdown.active .user-dropdown-content {
            display: block;
        }
        .container {
            padding-top: 20px;
            margin-left: 270px;
            margin-right: 10px;
            padding: 10px;
            border-radius: 15px; /* Add rounded corners */
            background-color: #f0f5f7; /* Optional: add background color */
        }
        h1 {
            font-size: 30px;
            font-weight: bold;
            color: #04295b;
            text-align: center;
        }
        h3 {
            font-size: 15px;
            font-style: italic;
            color: #d13747;
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 20px;
        }
        input[type="text"],
        input[type="date"] {
            text-align: center;
            padding: 20px 0;
            border: 2px solid #ccc;
            border-radius: 10px;
            width: 100%;
        }
        #playerDetails {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            background: #f0f5f7;
            padding: 20px;
            border-radius: 5px;
            width: 100%;
            max-width: 50%;
            margin: 0 auto;
        }
        .player-info {
            flex-basis: 40%;
            margin-bottom: 10px;
        }
        .player-info p {
            margin: 5px 0;
            font-size: 20px;
            line-height: 1.6;
            font-style: italic;
            color: #04295b;
        }
        .player-photo {
            flex-basis: 40%;
            display: flex;
            justify-content: flex-end;
        }
        .player-photo-img {
            width: 180px;
            height: auto;
        }
        .btn {
            padding: 10px 20px;
            background-color: #d13747;
            color: #fff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            font-weight: 700;
            text-align: center;
            margin: 5px;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #04295b;
        }
        .error {
            color: red;
            font-weight: bold;
            text-align: center;
        }
        .success {
            color: green;
            font-weight: bold;
        }
        table {
            width: 100%; /* Make the table take full width */
            border-collapse: collapse;
            margin-bottom: 20px;
            border-radius: 10px; /* Add rounded corners to the table */
            overflow: hidden; /* Ensures the rounded corners are applied */
        }

        th, td {
            padding: 12px; /* Increase padding for a cleaner look */
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #d13747; /* Change header background color */
            color: white; /* Change header text color */
        }

        tr:nth-child(even) {
            background-color: #f2f2f2; /* Alternate row background color */
        }

        tr:hover {
            background-color: #ddd; /* Add hover effect on rows */
        }

        .status {
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: bold;
            color: white;
            text-align: center;
            display: inline-block;
        }

        .status.ongoing {
            background-color: green;
        }

        .status.concluded {
            background-color: red;
        }

        .status.upcoming {
            background-color: orange;
        }

        /* Responsive styles for smaller screens */
        @media screen and (max-width: 600px) {
            table {
                font-size: 14px;
            }

            th, td {
                padding: 8px;
            }

            #btn {
                padding: 6px 12px;
            }
        }

    </style>

    <title>Manage Leagues</title>
    </head>
    <body>
    <div id="top-bar">
        <div class="logo">
            <a href="#"><span class="logo-my">My</span><span class="logo-safa">SAFA</span></a>
        </div>
        <div class="user-dropdown">
            <?php echo htmlspecialchars($_SESSION['username']); ?> <i class="fa fa-caret-down"></i>
            <div class="user-dropdown-content">
                <a href="#">Profile</a>
                <a href="#">Settings</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div>

    <div class="sidebar">
        <div class="menu">
            <ul>
                <li><a href="dashboard.php" ><i class="fa fa-dashboard fa-2x nav-icon"></i><span class="nav-text">Dashboard</span></a></li>
                <li class="dropdown">
                    <a href="#"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Manage</span><i class="fa fa-angle-down fa-2x nav-icon"></i></a>
                    <div class="dropdown-content">
                        <a href="manage_leagues.php" class="current">Manage League</a>
                        <a href="manage_teams.php">Manage Team</a>
                        <a href="manage_players.php">Manage Players</a>
                    </div>
                </li>
                <li><a href="register.php"><i class="fa fa-home fa-2x nav-icon"></i><span class="nav-text">Register Player</span></a></li>
                <li><a href="register_team.php"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Register Club</span></a></li>
                <li><a href="register_league.php"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Register League</span></a></li>
            </ul>
            <ul class="logout">
                <li>
                    <a href="logout.php">
                        <i class="fa fa-power-off fa-2x nav-icon"></i>
                        <span class="nav-text">Logout</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <br>

    <div class="container">
        <h1>Manage League</h1>
       
        <main>
            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
            <?php elseif ($success): ?>
                <p class="success"><?php echo htmlspecialchars($success); ?></p>
            <?php endif; ?>

            <form method="POST" action="manage_leagues.php">
                <label for="league_name">League Name:</label>
                <input type="text" id="league_name" name="league_name" required placeholder="Enter League Name">
                
                <label for="start_date">Start Date:</label>
                <input type="date" id="start_date" name="start_date" required placeholder="Enter Start Date">
                
                <button type="submit" name="add_league" class="btn">Add League</button>
            </form>

            <table>
                <thead>
                    <tr>
                        <th>League ID</th>
                        <th>League Name</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($leagues as $league): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($league['league_id']); ?></td>
                            <td><?php echo htmlspecialchars($league['name']); ?></td>
                            <td><?php echo htmlspecialchars($league['start_date']); ?></td>
                            <td><?php echo htmlspecialchars($league['end_date']); ?></td>
                            <td>
                                <span class="status <?php echo htmlspecialchars($league['status_class']); ?>">
                                    <?php echo htmlspecialchars($league['status']); ?>
                                </span>
                            </td>
                            
                            <td><a href="#" onclick="confirmDelete(<?php echo htmlspecialchars($league['league_id']); ?>)" class="btn">Delete</a></td>
                            
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

        </main>
    </div>
    <script>
        function confirmDelete(leagueId) {
            if (confirm("Are you sure you want to delete this league?")) {
                window.location.href = `manage_leagues.php?delete_id=${leagueId}`;
            }
        }
    </script>

    <script>
        document.querySelectorAll('.dropdown > a').forEach((dropdownToggle) => {
            dropdownToggle.addEventListener('click', function (event) {
                event.preventDefault();
                const dropdown = this.parentElement;
                dropdown.classList.toggle('active');
            });
        });

        document.querySelector('.user-dropdown').addEventListener('click', function () {
            this.classList.toggle('active');
        });
    </script>
</body>
</html>
