<?php
    session_start();
    if (!isset($_SESSION['username'])) {
        header("Location: login.php");
        exit();
    }

    include 'db.php';

    // Handle player deletion
    if (isset($_GET['delete_id'])) {
        $deleteId = $_GET['delete_id'];
        $deleteQuery = $conn->prepare("DELETE FROM players WHERE id = ?");
        $deleteQuery->bind_param("i", $deleteId);
        if ($deleteQuery->execute()) {
            $success = "Player deleted successfully.";
        } else {
            $error = "Failed to delete player.";
        }
        $deleteQuery->close();
    }
    // Fetch all registered players with their team names
    $query = $conn->query("
        SELECT players.*, teams.name AS team_name, leagues.name AS league_name
        FROM players
        LEFT JOIN teams ON players.team_id = teams.team_id
        LEFT JOIN leagues ON teams.league_id = leagues.league_id
    ");
    $players = [];
    while ($row = $query->fetch_assoc()) {
        $players[] = $row;
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <title>Manage Players</title>
    <style>
        @import url("https://fonts.googleapis.com/css?family=Open+Sans&display=swap");

        body {
            font-family: 'Roboto', sans-serif;
            background-color: #04295b;
            margin: 0;
            padding: 0;
        }

        #top-bar {
            background-color: #000000;
            padding: 10px 20px;
            padding-right: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        #top-bar .logo {
            font-size: 24px;
            font-weight: bold;
            display: flex;
            align-items: center;
        }

        #top-bar .logo a {
            text-decoration: none;
            font-size: 1.8em;
            font-weight: bold;
            color: #f0f5f7;
        }

        #top-bar .logo a .logo-my {
            color: #d13747;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif, sans-serif;
            font-style: italic;
        }

        #top-bar .logo a .logo-safa {
            color: #f0f5f7;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif, sans-serif;
            font-style: italic;
        }

        #top-bar div {
            color: white;
        }

        .sidebar {
            width: 250px;
            background-color: #003366;
            position: fixed;
            height: 100%;
            padding-top: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .sidebar ul li {
            width: 100%;
        }

        .sidebar ul li a {
            display: block;
            color: white;
            padding: 10px;
            text-decoration: none;
        }

        .sidebar ul li a .nav-icon {
            display: table-cell;
            width: 60px;
            height: 36px;
            text-align: center;
            vertical-align: middle;
            font-size: 18px;
        }

        .sidebar ul li a .nav-text {
            display: table-cell;
            vertical-align: middle;
            width: 150px;
            font-family: 'Titillium Web', sans-serif;
        }

        .sidebar ul li a:hover,
        .sidebar ul li a.current {
            background-color: #04295b;
            color: #d13747;
        }

        .sidebar ul.logout {
            position: absolute;
            bottom: 11%;
            background-color: red;
            color: #fff;
            text-align: center;
            width: 100%;
        }

        .dropdown {
            position: relative;
        }

        .dropdown-content {
            display: none;
            flex-direction: column;
            background-color: #003366;
            padding: 0;
            width: 100%;
        }

        .dropdown-content a {
            padding: 10px;
            color: white;
            text-decoration: none;
        }

        .dropdown-content a:hover {
            background-color: #04295b;
        }

        .dropdown.active .dropdown-content {
            display: flex;
        }

        .user-dropdown {
            position: relative;
            cursor: pointer;
        }

        .user-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        .user-dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .user-dropdown-content a:hover {
            background-color: #ddd;
            color: black;
        }

        .user-dropdown.active .user-dropdown-content {
            display: block;
        }

        .container {
            padding-top: 20px;
            margin-left: 270px;
            margin-right: 10px;
            padding: 10px;
            border-radius: 15px;
            background-color: #f0f5f7;
        }

        h1 {
            font-size: 30px;
            font-weight: bold;
            color: #04295b;
            text-align: center;
        }

        h3 {
            font-size: 15px;
            font-style: italic;
            color: #d13747;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 20px;
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        label {
            font-size: 14px;
            color: #333;
        }

        input[type="text"],
        input[type="date"],
        input[type="email"],
        select {
            text-align: left;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: auto;
            font-size: 14px;
        }

        img.player-photo {
            width: 100%;
            max-width: 150px;
            margin-bottom: 10px;
        }

        .btn {
            padding: 10px 20px;
            background-color: #d13747;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 700;
            text-align: center;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #04295b;
        }

        .error {
            color: red;
            font-weight: bold;
            text-align: center;
        }

        .success {
            color: green;
            font-weight: bold;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #d13747;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        .status {
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: bold;
            color: white;
            text-align: center;
            display: inline-block;
        }

        .status.active {
            background-color: green;
        }

        .status.notactive {
            background-color: red;
        }

        .status.pending {
            background-color: orange;
        }


        @media screen and (max-width: 600px) {
            table {
                font-size: 14px;
            }

            th, td {
                padding: 8px;
            }

            #btn {
                padding: 6px 12px;
            }
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0,0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>

</head>
<body>
    <div id="top-bar">
        <div class="logo">
            <a href="#"><span class="logo-my">My</span><span class="logo-safa">SAFA</span></a>
        </div>
        <div class="user-dropdown">
            <?php echo htmlspecialchars($_SESSION['username']); ?> <i class="fa fa-caret-down"></i>
            <div class="user-dropdown-content">
                <a href="#">Profile</a>
                <a href="#">Settings</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div>
    
    <div class="sidebar">
        <div class="menu">
            <ul>
                <li><a href="dashboard.php"><i class="fa fa-dashboard fa-2x nav-icon"></i><span class="nav-text">Dashboard</span></a></li>
                <li class="dropdown">
                    <a href="#"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Manage</span><i class="fa fa-angle-down fa-2x nav-icon"></i></a>
                    <div class="dropdown-content">
                        <a href="manage_leagues.php">Manage League</a>
                        <a href="manage_teams.php">Manage Team</a>
                        <a href="manage_players.php" class="current">Manage Players</a>
                    </div>
                </li>
                <li><a href="register.php"><i class="fa fa-home fa-2x nav-icon"></i><span class="nav-text">Register Player</span></a></li>
                <li><a href="register_team.php"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Register Club</span></a></li>
                <li><a href="register_league.php"><i class="fa fa-users fa-2x nav-icon"></i><span class="nav-text">Register League</span></a></li>
            </ul>
            <ul class="logout">
                <li>
                    <a href="logout.php">
                        <i class="fa fa-power-off fa-2x nav-icon"></i>
                        <span class="nav-text">Logout</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <br>

    <div class="container">
        <header>
            <h1>Manage Players</h1>
        </header>
        <main>
            <table>
                <thead>
                    <tr>
                        <th>ID Number</th>
                        <th>Full Name</th>
                        <th>League</th>
                        <th>Team</th>
                        <th>Contact Number</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Action</th>
                        <th>View Document</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($players as $player): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($player['id_number']); ?></td>
                            <td><?php echo htmlspecialchars($player['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($player['league_name'] ?? 'No League'); ?></td>
                            <td><?php echo htmlspecialchars($player['team_name'] ?? 'No Team'); ?></td>
                            <td><?php echo htmlspecialchars($player['contact_number']); ?></td>
                            <td><?php echo htmlspecialchars($player['email']); ?></td>
                            <td class="status <?php echo strtolower($player['status']); ?>"><?php echo htmlspecialchars($player['status']); ?></td>
                            <td><button class="btn edit-player" data-id="<?php echo htmlspecialchars($player['id']); ?>">Manage Player</button></td>
                            <td><button class="btn view-document" data-id-number="<?php echo htmlspecialchars($player['id_number']); ?>">View Document</button></td>
                            <td><a href="#" onclick="confirmDelete(<?php echo htmlspecialchars($player['id']); ?>)" class="btn">Delete</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </main>
    </div>

    <!-- The Modal -->
    <div id="editPlayerModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <div id="modal-body"></div>
        </div>
    </div>

    <!-- The Modal for Viewing Documents -->
    <div id="viewDocumentModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <div id="document-content">
                <!-- Document content will be loaded here -->
            </div>
        </div>
    </div>
    
    <script>
        function confirmDelete(playerId) {
            if (confirm("Are you sure you want to delete this player?")) {
                window.location.href = `manage_players.php?delete_id=${playerId}`;
            }
        }
    </script>

    <script>
        // Dropdown logic...
        document.querySelectorAll('.dropdown > a').forEach((dropdownToggle) => {
            dropdownToggle.addEventListener('click', function (event) {
                event.preventDefault();
                const dropdown = this.parentElement;
                dropdown.classList.toggle('active');
            });
        });

        document.querySelector('.user-dropdown').addEventListener('click', function () {
            this.classList.toggle('active');
        });

        // Modal logic
        const editModal = document.getElementById("editPlayerModal");
        const viewModal = document.getElementById("viewDocumentModal");
        const closeButtons = document.getElementsByClassName("close");

        document.querySelectorAll('.edit-player').forEach(button => {
            button.addEventListener('click', function () {
                const playerId = this.getAttribute('data-id');
                fetch(`edit_player.php?id=${playerId}`)
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById('modal-body').innerHTML = data;
                        editModal.style.display = "block";

                        const form = document.getElementById('editPlayerForm');
                        form.addEventListener('submit', function (event) {
                            event.preventDefault();

                            const formData = new FormData(form);
                            fetch('edit_player.php', {
                                method: 'POST',
                                body: formData
                            })
                            .then(response => response.json())
                            .then(result => {
                                if (result.success) {
                                    alert('Player updated successfully');
                                    editModal.style.display = "none";
                                    location.reload(); // Reload the page to reflect changes
                                } else {
                                    alert('Error updating player');
                                }
                            })
                            .catch(error => {
                                console.error('Error:', error);
                                alert('Error updating player');
                            });
                        });
                    });
            });
        });

        document.querySelectorAll('.view-document').forEach(button => {
            button.addEventListener('click', function () {
                const idNumber = this.getAttribute('data-id-number');
                const documentContent = document.getElementById('document-content');
                documentContent.innerHTML = `<embed src='view_document.php?id_number=${encodeURIComponent(idNumber)}' width='100%' height='600px' />`;
                viewModal.style.display = "block";
            });
        });

        for (let i = 0; i < closeButtons.length; i++) {
            closeButtons[i].onclick = function() {
                editModal.style.display = "none";
                viewModal.style.display = "none";
            }
        }

        window.onclick = function(event) {
            if (event.target == editModal) {
                editModal.style.display = "none";
            }
            if (event.target == viewModal) {
                viewModal.style.display = "none";
            }
        }
    </script>


</body>
</html>
