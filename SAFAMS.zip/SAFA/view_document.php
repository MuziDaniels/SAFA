<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$idNumber = $_GET['id_number'] ?? null;

if ($idNumber) {
    // Prepare the query to fetch the document details
    $query = $conn->prepare("SELECT document_name, document_type FROM documents WHERE id_number = ?");
    if ($query === false) {
        // Handle query preparation error
        die("Error preparing the query: " . $conn->error);
    }

    $query->bind_param("s", $idNumber);
    $query->execute();

    $result = $query->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $documentPath = 'uploads/' . $row['document_name'];

        if (file_exists($documentPath)) {
            // Serve the document for embedding
            header('Content-Type: ' . $row['document_type']);
            readfile($documentPath);
        } else {
            echo "Document not found.";
        }
    } else {
        echo "No documents found for this player.";
    }

    $query->close();
} else {
    echo "Invalid player ID number.";
}
?>
